
import React, { useState, useEffect, useCallback } from 'react';
import { AdminUser, UserRole, CustomerInfo } from '../types';

// --- ICONS (inlined to avoid creating many new files) ---
const DashboardIcon = () => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="3" width="7" height="9"></rect><rect x="14" y="3" width="7" height="5"></rect><rect x="14" y="12" width="7" height="9"></rect><rect x="3" y="16" width="7" height="5"></rect></svg>;
const UsersIcon = () => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M22 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>;
const KnowledgeIcon = () => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H20v20H6.5a2.5 2.5 0 0 1 0-5H20"></path></svg>;
const LogoutIcon = () => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path><polyline points="16 17 21 12 16 7"></polyline><line x1="21" y1="12" x2="9" y2="12"></line></svg>;
const ChartIcon = () => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 3v18h18"/><path d="m19 9-5 5-4-4-3 3"/></svg>;

// --- MOCK DATA ---
const MOCK_CUSTOMERS: CustomerInfo[] = [
    { name: 'Trần Văn An', phone: '0901234567' },
    { name: 'Nguyễn Thị Bình', phone: '0912345678' },
    { name: 'Lê Minh Cường', phone: '0987654321' },
];

const MOCK_TRAFFIC_DATA = [
    { day: 'T2', visits: 65 }, { day: 'T3', visits: 59 },
    { day: 'T4', visits: 80 }, { day: 'T5', visits: 81 },
    { day: 'T6', visits: 56 }, { day: 'T7', visits: 95 },
    { day: 'CN', visits: 110 }
];


// --- ADMIN SUB-COMPONENTS ---

const StatCard = ({ title, value, icon, period }) => (
    <div className="bg-gray-800 p-6 rounded-lg shadow-lg flex items-center space-x-4">
        <div className="bg-green-800 p-3 rounded-full">{icon}</div>
        <div>
            <p className="text-sm text-gray-400">{title}</p>
            <p className="text-2xl font-bold text-white">{value}</p>
            <p className="text-xs text-gray-500">{period}</p>
        </div>
    </div>
);

const DashboardView = () => (
    <div className="space-y-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <StatCard title="Traffic truy cập" value="110" icon={<ChartIcon />} period="Hôm nay" />
            <StatCard title="Lượt hỏi đáp" value="734" icon={<UsersIcon />} period="Tuần này" />
            <StatCard title="Khách hàng tiềm năng" value="12" icon={<KnowledgeIcon />} period="Tháng này" />
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
             <div className="bg-gray-800 p-6 rounded-lg shadow-lg">
                <h3 className="font-bold text-lg mb-4 text-white">Lịch sử truy cập (7 ngày qua)</h3>
                <div className="h-60 flex items-end justify-between px-2">
                   {MOCK_TRAFFIC_DATA.map(d => (
                       <div key={d.day} className="flex flex-col items-center w-1/8">
                           <div className="w-6 bg-green-600 hover:bg-green-500 transition-all" style={{height: `${(d.visits/120)*100}%`}}></div>
                           <p className="text-xs mt-2 text-gray-400">{d.day}</p>
                       </div>
                   ))}
                </div>
            </div>
            <div className="bg-gray-800 p-6 rounded-lg shadow-lg">
                <h3 className="font-bold text-lg mb-4 text-white">Khách hàng mới nhất</h3>
                <ul className="space-y-4">
                    {MOCK_CUSTOMERS.map((c, i) => (
                        <li key={i} className="flex justify-between items-center text-sm">
                            <span className="text-gray-300">{c.name}</span>
                            <span className="font-mono text-green-400">{c.phone}</span>
                        </li>
                    ))}
                </ul>
            </div>
        </div>
    </div>
);

const UserManagementView = () => {
    const [users, setUsers] = useState<AdminUser[]>([]);
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [role, setRole] = useState<UserRole>(UserRole.STAFF);

    useEffect(() => {
        const storedUsers = JSON.parse(localStorage.getItem('chay-tue-users') || '[]');
        if (storedUsers.length === 0) {
            // Seed with default admin user if none exist
            const adminUser: AdminUser = { id: 'admin-0', username: 'Testchatbot', password: 'Testchatbot', role: UserRole.ADMIN };
            localStorage.setItem('chay-tue-users', JSON.stringify([adminUser]));
            setUsers([adminUser]);
        } else {
            setUsers(storedUsers);
        }
    }, []);

    const handleAddUser = (e: React.FormEvent) => {
        e.preventDefault();
        if(!username || !password) return alert("Vui lòng nhập tên người dùng và mật khẩu.");
        const newUser: AdminUser = { id: `user-${Date.now()}`, username, password, role };
        const updatedUsers = [...users, newUser];
        setUsers(updatedUsers);
        localStorage.setItem('chay-tue-users', JSON.stringify(updatedUsers));
        setUsername('');
        setPassword('');
    };
    
    return (
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-gray-800 p-6 rounded-lg shadow-lg">
           <h3 className="font-bold text-lg mb-4 text-white">Danh sách người dùng</h3>
           <div className="overflow-x-auto">
                <table className="w-full text-left">
                    <thead className="border-b border-gray-600 text-sm text-gray-400">
                        <tr>
                            <th className="p-2">Tên người dùng</th>
                            <th className="p-2">Vai trò</th>
                        </tr>
                    </thead>
                    <tbody>
                        {users.map(user => (
                            <tr key={user.id} className="border-b border-gray-700 text-gray-300">
                                <td className="p-3">{user.username}</td>
                                <td className="p-3">
                                    <span className={`px-2 py-1 text-xs rounded-full ${user.role === UserRole.ADMIN ? 'bg-red-800 text-red-200' : 'bg-green-800 text-green-200'}`}>
                                        {user.role === UserRole.ADMIN ? 'Quản trị viên' : 'Chăm sóc khách hàng'}
                                    </span>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
           </div>
        </div>
        <div className="bg-gray-800 p-6 rounded-lg shadow-lg">
            <h3 className="font-bold text-lg mb-4 text-white">Tạo người dùng mới</h3>
            <form onSubmit={handleAddUser} className="space-y-4">
                <div>
                    <label className="text-sm text-gray-400 block mb-1">Tên đăng nhập</label>
                    <input type="text" value={username} onChange={e => setUsername(e.target.value)} className="w-full p-2 bg-gray-700 border border-gray-600 rounded focus:outline-none focus:ring-2 focus:ring-green-500" />
                </div>
                 <div>
                    <label className="text-sm text-gray-400 block mb-1">Mật khẩu</label>
                    <input type="password" value={password} onChange={e => setPassword(e.target.value)} className="w-full p-2 bg-gray-700 border border-gray-600 rounded focus:outline-none focus:ring-2 focus:ring-green-500" />
                </div>
                 <div>
                    <label className="text-sm text-gray-400 block mb-1">Vai trò</label>
                    <select value={role} onChange={e => setRole(e.target.value as UserRole)} className="w-full p-2 bg-gray-700 border border-gray-600 rounded focus:outline-none focus:ring-2 focus:ring-green-500">
                        <option value={UserRole.STAFF}>Chăm sóc khách hàng</option>
                        <option value={UserRole.ADMIN}>Quản trị viên</option>
                    </select>
                </div>
                <button type="submit" className="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded transition-colors">Thêm người dùng</button>
            </form>
        </div>
      </div>
    );
};

const KnowledgeEditorView = () => {
    const [knowledge, setKnowledge] = useState('');
    const [status, setStatus] = useState('');

    useEffect(() => {
        const storedKnowledge = localStorage.getItem('chay-tue-knowledge');
        const defaultKnowledge = `
# TỔNG HỢP THÔNG TIN VỀ NHÀ HÀNG CHAY TUỆ

## 1. GIỚI THIỆU & TRIẾT LÝ
- **Khởi nguồn**: Ẩm Thực Chay Tuệ là chuỗi nhà hàng chay cao cấp với tâm nguyện lan tỏa văn hóa ăn chay, nuôi dưỡng nhân tâm. Sứ mệnh là "Giữ chánh niệm – Sống bình an".
- **Triết lý "Tuệ"**: Tên gọi mang ý nghĩa Giới – Định – Tuệ theo lời dạy của Đức Phật, giúp con người giác ngộ và hiểu rõ bản thân.
`;
        setKnowledge(storedKnowledge || defaultKnowledge.trim());
    }, []);

    const handleSave = () => {
        localStorage.setItem('chay-tue-knowledge', knowledge);
        setStatus('Đã lưu kiến thức thành công!');
        setTimeout(() => setStatus(''), 3000);
    };

    return (
        <div className="bg-gray-800 p-6 rounded-lg shadow-lg">
            <h3 className="font-bold text-lg mb-4 text-white">Cập nhật kiến thức cho Chatbot</h3>
            <p className="text-sm text-gray-400 mb-4">Chỉnh sửa nội dung dưới đây để thay đổi thông tin mà chatbot sử dụng để trả lời. Hỗ trợ định dạng Markdown.</p>
            <textarea
                value={knowledge}
                onChange={e => setKnowledge(e.target.value)}
                className="w-full h-96 p-3 font-mono text-sm bg-gray-900 border border-gray-600 rounded focus:outline-none focus:ring-2 focus:ring-green-500"
            />
            <div className="mt-4 flex items-center justify-between">
                <button onClick={handleSave} className="bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-6 rounded transition-colors">Lưu thay đổi</button>
                {status && <p className="text-green-400 text-sm">{status}</p>}
            </div>
        </div>
    )
}


const AdminLogin = ({ onLogin }) => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        // In a real app, you would fetch users and check password hash
        if (username === 'Testchatbot' && password === 'Testchatbot') {
            onLogin();
        } else {
            setError('Tên đăng nhập hoặc mật khẩu không chính xác.');
        }
    };

    return (
        <div className="flex items-center justify-center min-h-screen bg-gray-900 text-white">
            <div className="w-full max-w-md p-8 space-y-8 bg-gray-800 rounded-lg shadow-xl">
                <div className="text-center">
                    <h1 className="text-3xl font-bold text-green-400">Chay Tuệ AI</h1>
                    <p className="mt-2 text-gray-400">Trang quản trị Chatbot</p>
                </div>
                <form onSubmit={handleSubmit} className="space-y-6">
                    <div>
                        <label className="text-sm font-bold text-gray-400 block mb-2">Tên đăng nhập</label>
                        <input
                            type="text"
                            value={username}
                            onChange={(e) => setUsername(e.target.value)}
                            className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                        />
                    </div>
                    <div>
                        <label className="text-sm font-bold text-gray-400 block mb-2">Mật khẩu</label>
                        <input
                            type="password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            className="w-full p-3 bg-gray-700 border border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                        />
                    </div>
                    {error && <p className="text-red-400 text-sm">{error}</p>}
                    <button type="submit" className="w-full py-3 px-4 bg-green-600 hover:bg-green-700 rounded-lg text-white font-bold text-lg transition-colors">
                        Đăng nhập
                    </button>
                </form>
            </div>
        </div>
    );
};

const AdminDashboard = ({ onLogout }) => {
    const [activeView, setActiveView] = useState('dashboard');
    
    const navItems = [
        { id: 'dashboard', label: 'Bảng điều khiển', icon: <DashboardIcon /> },
        { id: 'users', label: 'Quản lý người dùng', icon: <UsersIcon /> },
        { id: 'knowledge', label: 'Cập nhật kiến thức', icon: <KnowledgeIcon /> },
    ];

    const renderContent = () => {
        switch (activeView) {
            case 'users': return <UserManagementView />;
            case 'knowledge': return <KnowledgeEditorView />;
            case 'dashboard':
            default:
                return <DashboardView />;
        }
    };

    return (
        <div className="flex min-h-screen bg-gray-900 text-white font-sans">
            <aside className="w-64 bg-gray-800 p-4 flex flex-col">
                <div className="text-center mb-10">
                    <h2 className="text-2xl font-bold text-green-400">Chay Tuệ AI</h2>
                    <p className="text-xs text-gray-400">Admin Panel</p>
                </div>
                <nav className="flex-1 space-y-2">
                    {navItems.map(item => (
                        <button
                            key={item.id}
                            onClick={() => setActiveView(item.id)}
                            className={`w-full flex items-center space-x-3 p-3 rounded-lg text-left transition-colors ${activeView === item.id ? 'bg-green-800 text-white' : 'text-gray-400 hover:bg-gray-700 hover:text-white'}`}
                        >
                            {item.icon}
                            <span>{item.label}</span>
                        </button>
                    ))}
                </nav>
                <div>
                     <button
                        onClick={onLogout}
                        className="w-full flex items-center space-x-3 p-3 rounded-lg text-left text-gray-400 hover:bg-gray-700 hover:text-white transition-colors"
                     >
                        <LogoutIcon />
                        <span>Đăng xuất</span>
                    </button>
                </div>
            </aside>
            <main className="flex-1 p-8 overflow-auto">
                {renderContent()}
            </main>
        </div>
    );
};

const Admin = () => {
    const [isLoggedIn, setIsLoggedIn] = useState(false);

    useEffect(() => {
        // Check session storage for login status
        const sessionActive = sessionStorage.getItem('chay-tue-admin-session') === 'true';
        setIsLoggedIn(sessionActive);
    }, []);

    const handleLogin = () => {
        sessionStorage.setItem('chay-tue-admin-session', 'true');
        setIsLoggedIn(true);
    };
    
    const handleLogout = () => {
        sessionStorage.removeItem('chay-tue-admin-session');
        setIsLoggedIn(false);
    };

    if (!isLoggedIn) {
        return <AdminLogin onLogin={handleLogin} />;
    }

    return <AdminDashboard onLogout={handleLogout} />;
};

export default Admin;
