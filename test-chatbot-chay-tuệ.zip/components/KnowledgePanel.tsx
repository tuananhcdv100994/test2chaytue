
import React from 'react';
import InfoIcon from './icons/InfoIcon';

interface KnowledgePanelProps {
  knowledge: string;
  setKnowledge: (value: string) => void;
}

const KnowledgePanel: React.FC<KnowledgePanelProps> = ({ knowledge, setKnowledge }) => {
  return (
    <div className="bg-gray-100 dark:bg-gray-800 p-4 rounded-lg">
      <h2 className="text-lg font-semibold mb-2 flex items-center gap-2">
        <InfoIcon />
        <span>Kiến Thức Nền</span>
      </h2>
      <p className="text-sm text-gray-500 dark:text-gray-400 mb-3">
        Cung cấp thông tin để chatbot trả lời chính xác hơn.
      </p>
      <textarea
        value={knowledge}
        onChange={(e) => setKnowledge(e.target.value)}
        placeholder="Ví dụ:
- Giờ mở cửa: 8h - 22h
- Địa chỉ: 123 Đường ABC, Quận 1
- Món đặc biệt: Phở nấm chay"
        className="w-full h-48 p-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-green-500 text-sm"
      />
    </div>
  );
};

export default KnowledgePanel;
