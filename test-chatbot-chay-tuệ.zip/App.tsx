
import React, { useState, useCallback, useEffect } from 'react';
import { Message, Role, CustomerInfo } from './types';
import { getBotResponse } from './services/geminiService';
import ChatInterface from './components/ChatInterface';
import CustomerInfoPanel from './components/CustomerInfoPanel';
import Admin from './pages/Admin';

const ChatApp = () => {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: Role.MODEL,
      parts: [{ text: 'Dạ, Chay Tuệ xin chào Anh/Chị ạ. Tôi có thể giúp gì cho Anh/Chị hôm nay? 😊' }],
      id: 'initial-message'
    }
  ]);
  const [customerInfo, setCustomerInfo] = useState<CustomerInfo>({ name: '', phone: '' });
  const [isLoading, setIsLoading] = useState<boolean>(false);

  const handleSendMessage = useCallback(async (userInput: string) => {
    if (!userInput.trim()) return;

    const userMessage: Message = {
      role: Role.USER,
      parts: [{ text: userInput }],
      id: `user-${Date.now()}`
    };
    setMessages(prevMessages => [...prevMessages, userMessage]);
    setIsLoading(true);

    try {
      const { responseText, extractedInfo } = await getBotResponse(userInput, messages);

      const botMessage: Message = {
        role: Role.MODEL,
        parts: [{ text: responseText }],
        id: `bot-${Date.now()}`
      };
      setMessages(prevMessages => [...prevMessages, botMessage]);

      if (extractedInfo?.name || extractedInfo?.phone) {
        setCustomerInfo(prevInfo => ({
          name: extractedInfo.name || prevInfo.name,
          phone: extractedInfo.phone || prevInfo.phone,
        }));
      }

    } catch (error) {
      console.error("Error getting bot response:", error);
      const errorMessage: Message = {
        role: Role.MODEL,
        parts: [{ text: 'Xin lỗi, tôi đang gặp sự cố. Anh/Chị vui lòng thử lại sau. 🤖' }],
        id: `error-${Date.now()}`
      };
      setMessages(prevMessages => [...prevMessages, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  }, [messages]);

  return (
    <div className="flex h-screen font-sans text-gray-800 dark:text-gray-200 bg-gray-50 dark:bg-gray-800">
      <div className="w-96 flex-shrink-0 flex flex-col p-4 space-y-4 bg-white dark:bg-gray-900 border-r border-gray-200 dark:border-gray-700">
        <h1 className="text-2xl font-bold text-center text-green-700 dark:text-green-400">Chay Tuệ AI</h1>
        <CustomerInfoPanel customerInfo={customerInfo} />
      </div>
      <div className="flex-1 flex flex-col">
        <ChatInterface
          messages={messages}
          onSendMessage={handleSendMessage}
          isLoading={isLoading}
        />
        <footer className="flex justify-center items-center space-x-4 p-2 text-xs text-gray-500 dark:text-gray-400 bg-gray-100 dark:bg-gray-900/50">
          <span>Chatbot Ẩm Thực Chay Tuệ by Plugai.top</span>
        </footer>
      </div>
    </div>
  );
};

function App() {
  const [route, setRoute] = useState(window.location.pathname);

  useEffect(() => {
    const handlePopState = () => {
      setRoute(window.location.pathname);
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  if (route.startsWith('/admin')) {
    return <Admin />;
  }

  return <ChatApp />;
}


export default App;