import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { AdminUser, AdminRole, Message, CustomerInfo, Role } from '../types';
import { getAdmins, saveAdmins } from '../lib/storage';
import HomeIcon from '../components/icons/HomeIcon';
import ChatBubbleIcon from '../components/icons/ChatBubbleIcon';
import UsersIcon from '../components/icons/UsersIcon';
import ChartBarIcon from '../components/icons/ChartBarIcon';
import UserCogIcon from '../components/icons/UserCogIcon';
import LogoutIcon from '../components/icons/LogoutIcon';
import BotIcon from '../components/icons/BotIcon';
import UserIcon from '../components/icons/UserIcon';
import PlusIcon from '../components/icons/PlusIcon';
import TrashIcon from '../components/icons/TrashIcon';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';


const API_BASE_URL = ''; // Relative path to use the same host

// --- Helper Components ---
const StatCard: React.FC<{ title: string; value: number | string; icon: React.ReactNode; color: string }> = ({ title, value, icon, color }) => (
    <div className={`p-6 rounded-2xl shadow-lg flex items-center space-x-4 ${color}`}>
        <div className="text-3xl">{icon}</div>
        <div>
            <p className="text-sm font-medium opacity-80">{title}</p>
            <p className="text-2xl font-bold">{value}</p>
        </div>
    </div>
);

const Section: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
    <div className="bg-gray-800/50 p-6 rounded-2xl shadow-xl">
        <h2 className="text-2xl font-bold text-gray-100 mb-4">{title}</h2>
        {children}
    </div>
);

// --- Admin Panels ---
const DashboardHome: React.FC<{ messages: Message[], customers: CustomerInfo[] }> = ({ messages, customers }) => (
    <div className="space-y-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <StatCard title="Tổng Tin Nhắn" value={messages.length} icon="💬" color="bg-blue-500 text-white" />
            <StatCard title="Khách Hàng Thu Thập" value={customers.length} icon="👥" color="bg-green-500 text-white" />
            <StatCard title="Nền tảng hoạt động" value={2} icon="🌐" color="bg-indigo-500 text-white" />
        </div>
        <Section title="Trạng thái Bot">
            <div className="overflow-x-auto">
                <table className="w-full text-left">
                    <thead className="border-b border-gray-600">
                        <tr>
                            <th className="p-3">Tên Chatbot</th>
                            <th className="p-3">Nền tảng</th>
                            <th className="p-3">Trạng thái</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr className="hover:bg-gray-700/50 transition-colors">
                            <td className="p-3 font-medium">Test chatbot Chay Tuệ</td>
                            <td className="p-3">Web</td>
                            <td className="p-3"><span className="px-3 py-1 text-xs font-semibold rounded-full bg-green-500/20 text-green-300">Hoạt động</span></td>
                        </tr>
                        <tr className="hover:bg-gray-700/50 transition-colors">
                            <td className="p-3 font-medium">Test chatbot Chay Tuệ</td>
                            <td className="p-3">Messenger</td>
                            <td className="p-3"><span className="px-3 py-1 text-xs font-semibold rounded-full bg-green-500/20 text-green-300">Hoạt động</span></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </Section>
    </div>
);

const ChatHistory: React.FC<{ messages: Message[] }> = ({ messages }) => (
     <Section title="Lịch sử Chat (Web & Messenger)">
        <div className="max-h-[60vh] overflow-y-auto space-y-6 pr-4">
            {[...messages].sort((a, b) => b.timestamp - a.timestamp).map(msg => (
                <div key={msg.id} className={`flex items-start gap-4 ${msg.role === Role.USER ? 'justify-end' : ''}`}>
                    {msg.role === Role.MODEL && <div className="flex-shrink-0 w-10 h-10 rounded-full bg-green-800 flex items-center justify-center text-green-300"><BotIcon /></div>}
                    <div className="flex flex-col">
                        <div className={`max-w-xl p-4 rounded-2xl ${msg.role === Role.USER ? 'bg-green-600 text-white rounded-br-none' : 'bg-gray-700 text-gray-200 rounded-bl-none'}`}>
                            <div className="prose prose-sm dark:prose-invert prose-p:my-1 prose-a:text-green-400 hover:prose-a:underline">
                                <ReactMarkdown remarkPlugins={[remarkGfm]}>{msg.parts[0].text}</ReactMarkdown>
                            </div>
                        </div>
                        <span className={`text-xs mt-1 ${msg.role === Role.USER ? 'text-right' : ''} text-gray-500`}>{new Date(msg.timestamp).toLocaleString()}</span>
                    </div>
                     {msg.role === Role.USER && <div className="flex-shrink-0 w-10 h-10 rounded-full bg-gray-600 flex items-center justify-center"><UserIcon /></div>}
                </div>
            ))}
        </div>
    </Section>
);

const CustomerList: React.FC<{ customers: CustomerInfo[] }> = ({ customers }) => (
    <Section title="Danh sách Khách hàng (Web & Messenger)">
        <div className="overflow-x-auto max-h-[60vh]">
            <table className="w-full text-left">
                <thead className="border-b border-gray-600 sticky top-0 bg-gray-800/50 backdrop-blur-sm">
                    <tr>
                        <th className="p-3">Tên Khách Hàng</th>
                        <th className="p-3">Số Điện Thoại</th>
                        <th className="p-3">Thời Gian Ghi Nhận</th>
                    </tr>
                </thead>
                <tbody>
                    {[...customers].sort((a,b) => b.timestamp - a.timestamp).map(customer => (
                        <tr key={customer.phone + customer.timestamp} className="border-b border-gray-700 hover:bg-gray-700/50 transition-colors">
                            <td className="p-3 font-medium">{customer.name || '(Chưa có tên)'}</td>
                            <td className="p-3">{customer.phone}</td>
                            <td className="p-3">{new Date(customer.timestamp).toLocaleString()}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    </Section>
);

const TrafficReport: React.FC<{ messages: Message[] }> = ({ messages }) => {
    const trafficData = useMemo(() => {
        const data: { [key: string]: number } = {};
        const today = new Date();
        today.setHours(0, 0, 0, 0);

        for (let i = 6; i >= 0; i--) {
            const date = new Date(today);
            date.setDate(today.getDate() - i);
            const key = date.toLocaleDateString('vi-VN', { day: '2-digit', month: '2-digit' });
            data[key] = 0;
        }

        messages.forEach(msg => {
            const msgDate = new Date(msg.timestamp);
            if (msgDate >= new Date(today.getTime() - 6 * 24 * 60 * 60 * 1000)) {
                 const key = msgDate.toLocaleDateString('vi-VN', { day: '2-digit', month: '2-digit' });
                 if(data[key] !== undefined) data[key]++;
            }
        });
        return data;
    }, [messages]);
    
    const maxTraffic = Math.max(...Object.values(trafficData), 1);

    return (
        <Section title="Báo cáo Traffic (7 ngày qua)">
            <div className="flex justify-around items-end h-64 bg-gray-800 p-4 rounded-lg">
                {Object.entries(trafficData).map(([day, count]) => (
                    <div key={day} className="flex flex-col items-center h-full justify-end">
                        <div className="text-sm font-bold text-white">{count}</div>
                        <div
                            className="w-10 bg-green-500 rounded-t-md hover:bg-green-400 transition-all"
                            style={{ height: `${(count / maxTraffic) * 90}%` }}
                            title={`${count} tin nhắn`}
                        ></div>
                        <div className="text-xs text-gray-400 mt-2">{day}</div>
                    </div>
                ))}
            </div>
        </Section>
    );
};

const AdminManagement: React.FC<{ currentUser: AdminUser }> = ({ currentUser }) => {
    const [admins, setAdmins] = useState(getAdmins());
    const [newUsername, setNewUsername] = useState('');
    const [newPassword, setPassword] = useState('');

    const handleAddAdmin = (e: React.FormEvent) => {
        e.preventDefault();
        if(!newUsername || !newPassword) return;

        const newAdmin = {
            id: `admin-${Date.now()}`,
            username: newUsername,
            // In a real app, send password to backend to hash. Here we mock it.
            passwordHash: `hashed_${newPassword}_mock`,
            role: AdminRole.ADMIN
        };
        const updatedAdmins = [...admins, newAdmin];
        setAdmins(updatedAdmins);
        saveAdmins(updatedAdmins);
        setNewUsername('');
        setPassword('');
    };

    const handleDeleteAdmin = (id: string) => {
        if(id === currentUser.id) {
            alert("Không thể xóa chính mình.");
            return;
        }
        const updatedAdmins = admins.filter(admin => admin.id !== id);
        setAdmins(updatedAdmins);
        saveAdmins(updatedAdmins);
    };

    return (
        <Section title="Quản lý Admin">
            {currentUser.role === AdminRole.SUPER && (
                 <form onSubmit={handleAddAdmin} className="mb-6 p-4 bg-gray-700/50 rounded-lg flex gap-4 items-center">
                    <input type="text" placeholder="Tên đăng nhập mới" value={newUsername} onChange={e => setNewUsername(e.target.value)} className="flex-grow bg-gray-800 border border-gray-600 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-green-500" />
                    <input type="password" placeholder="Mật khẩu" value={newPassword} onChange={e => setPassword(e.target.value)} className="flex-grow bg-gray-800 border border-gray-600 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-green-500" />
                    <button type="submit" className="bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded-md flex items-center gap-2 transition-colors"><PlusIcon/> Thêm</button>
                </form>
            )}
            <div className="overflow-x-auto">
                <table className="w-full text-left">
                     <thead className="border-b border-gray-600">
                        <tr>
                            <th className="p-3">Tên Đăng Nhập</th>
                            <th className="p-3">Vai Trò</th>
                            {currentUser.role === AdminRole.SUPER && <th className="p-3 text-right">Hành động</th>}
                        </tr>
                    </thead>
                    <tbody>
                        {admins.map(admin => (
                             <tr key={admin.id} className="border-b border-gray-700 hover:bg-gray-700/50">
                                <td className="p-3 font-medium">{admin.username}</td>
                                <td className="p-3">
                                    <span className={`px-2 py-0.5 text-xs font-semibold rounded-full ${admin.role === AdminRole.SUPER ? 'bg-yellow-500/20 text-yellow-300' : 'bg-blue-500/20 text-blue-300'}`}>
                                        {admin.role.toUpperCase()}
                                    </span>
                                </td>
                                {currentUser.role === AdminRole.SUPER && (
                                     <td className="p-3 text-right">
                                        {admin.role !== AdminRole.SUPER && (
                                            <button onClick={() => handleDeleteAdmin(admin.id)} className="text-red-400 hover:text-red-300 transition-colors"><TrashIcon/></button>
                                        )}
                                    </td>
                                )}
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </Section>
    )
};


// --- Main Admin View ---
const AdminView: React.FC<{ admin: AdminUser; onLogout: () => void }> = ({ admin, onLogout }) => {
  const [activePanel, setActivePanel] = useState('home');
  const [messages, setMessages] = useState<Message[]>([]);
  const [customers, setCustomers] = useState<CustomerInfo[]>([]);
  const [error, setError] = useState<string | null>(null);

  const fetchData = useCallback(async () => {
    try {
        const [messagesRes, customersRes] = await Promise.all([
            fetch(`${API_BASE_URL}/api/messages`),
            fetch(`${API_BASE_URL}/api/customers`)
        ]);
        if (!messagesRes.ok || !customersRes.ok) {
            throw new Error('Failed to fetch data from server.');
        }
        const messagesData = await messagesRes.json();
        const customersData = await customersRes.json();
        setMessages(messagesData);
        setCustomers(customersData);
        setError(null);
    } catch (err) {
        console.error("Fetch data error:", err);
        setError("Không thể tải dữ liệu từ server. Vui lòng kiểm tra lại kết nối và đảm bảo server đang chạy.");
    }
  }, []);

  useEffect(() => {
    fetchData(); // Fetch immediately on component mount
    const intervalId = setInterval(fetchData, 5000); // Poll every 5 seconds

    return () => clearInterval(intervalId); // Cleanup interval on unmount
  }, [fetchData]);


  const NavItem: React.FC<{ panel: string, icon: React.ReactNode, children: React.ReactNode }> = ({ panel, icon, children }) => (
    <li>
        <button
            onClick={() => setActivePanel(panel)}
            className={`w-full flex items-center gap-4 px-4 py-3 rounded-lg transition-colors ${activePanel === panel ? 'bg-green-600 text-white shadow-lg' : 'text-gray-300 hover:bg-gray-700/50 hover:text-white'}`}
        >
            {icon}
            <span className="font-semibold">{children}</span>
        </button>
    </li>
  );

  const renderPanel = () => {
    if (error) {
        return <Section title="Lỗi">{error}</Section>
    }
    switch (activePanel) {
      case 'home':
        return <DashboardHome messages={messages} customers={customers} />;
      case 'history':
        return <ChatHistory messages={messages} />;
      case 'customers':
        return <CustomerList customers={customers} />;
       case 'reports':
        return <TrafficReport messages={messages} />;
      case 'management':
        return <AdminManagement currentUser={admin} />;
      default:
        return <DashboardHome messages={messages} customers={customers} />;
    }
  };

  return (
    <div className="flex min-h-screen bg-gray-900 text-gray-200">
      <aside className="w-64 bg-gray-800/80 backdrop-blur-md p-6 flex flex-col border-r border-gray-700">
        <h1 className="text-2xl font-bold text-center text-green-400 mb-10">Admin</h1>
        <nav className="flex-grow">
          <ul className="space-y-3">
            <NavItem panel="home" icon={<HomeIcon />} >Tổng quan</NavItem>
            <NavItem panel="history" icon={<ChatBubbleIcon />}>Lịch sử Chat</NavItem>
            <NavItem panel="customers" icon={<UsersIcon />}>Khách hàng</NavItem>
            <NavItem panel="reports" icon={<ChartBarIcon />}>Báo cáo</NavItem>
            <NavItem panel="management" icon={<UserCogIcon />}>Quản lý Admin</NavItem>
          </ul>
        </nav>
        <div>
           <button onClick={onLogout} className="w-full flex items-center gap-4 px-4 py-3 rounded-lg text-red-400 hover:bg-red-500/20 hover:text-red-300 transition-colors">
                <LogoutIcon/>
                <span className="font-semibold">Đăng xuất</span>
            </button>
        </div>
      </aside>
      <main className="flex-1 flex flex-col">
        <header className="p-6 flex justify-between items-center bg-gray-800/50 border-b border-gray-700">
            <h2 className="text-xl font-semibold">Chào mừng trở lại, {admin.username}!</h2>
            <div className="text-sm text-gray-400">
                {new Date().toLocaleDateString('vi-VN', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
            </div>
        </header>
        <div className="flex-1 p-8 overflow-y-auto">
          {renderPanel()}
        </div>
      </main>
    </div>
  );
};

export default AdminView;