import React, { useState, useCallback } from 'react';
import { Message, Role, CustomerInfo } from '../types';
import { getBotResponse } from '../services/geminiService';
import { addMessage, addCustomer } from '../lib/storage';
import ChatInterface from '../components/ChatInterface';
import CustomerInfoPanel from '../components/CustomerInfoPanel';

function ChatView() {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: Role.MODEL,
      parts: [{ text: 'Xin chào! Tôi là Test chatbot Chay Tuệ. Tôi có thể giúp gì cho bạn hôm nay? 😊' }],
      id: 'initial-message',
      timestamp: Date.now(),
    }
  ]);
  const [customerInfo, setCustomerInfo] = useState<CustomerInfo>({ name: '', phone: '', timestamp: 0 });
  const [isLoading, setIsLoading] = useState<boolean>(false);

  const handleSendMessage = useCallback(async (userInput: string) => {
    if (!userInput.trim()) return;

    const timestamp = Date.now();
    const userMessage: Message = {
      role: Role.USER,
      parts: [{ text: userInput }],
      id: `user-${timestamp}`,
      timestamp,
    };
    
    setMessages(prevMessages => [...prevMessages, userMessage]);
    addMessage(userMessage);
    setIsLoading(true);

    try {
      const history = messages.map(({ id, role, parts, timestamp }) => ({ id, role, parts, timestamp }));
      const { responseText, extractedInfo, sources } = await getBotResponse(userInput, history);
      
      let botResponseText = responseText;
      if (sources && sources.length > 0) {
        const sourceList = sources.map(source => `*   [${source.title}](${source.uri})`).join('\n');
        botResponseText += `\n\n---\n**Nguồn tham khảo:**\n${sourceList}`;
      }
      
      const botTimestamp = Date.now();
      const botMessage: Message = {
        role: Role.MODEL,
        parts: [{ text: botResponseText }],
        id: `bot-${botTimestamp}`,
        timestamp: botTimestamp,
      };
      setMessages(prevMessages => [...prevMessages, botMessage]);
      addMessage(botMessage);

      if (extractedInfo?.name || extractedInfo?.phone) {
        const updatedInfo: CustomerInfo = {
            name: extractedInfo.name || customerInfo.name,
            phone: extractedInfo.phone || customerInfo.phone,
            timestamp: Date.now(),
        };
        setCustomerInfo(updatedInfo);
        if (updatedInfo.phone) { // Only save customer if phone number exists
            addCustomer(updatedInfo);
        }
      }

    } catch (error) {
      console.error("Error getting bot response:", error);
      const errorTimestamp = Date.now();
      const errorMessage: Message = {
        role: Role.MODEL,
        parts: [{ text: 'Xin lỗi, tôi đang gặp sự cố. Vui lòng thử lại sau. 🤖' }],
        id: `error-${errorTimestamp}`,
        timestamp: errorTimestamp
      };
      setMessages(prevMessages => [...prevMessages, errorMessage]);
      addMessage(errorMessage);
    } finally {
      setIsLoading(false);
    }
  }, [messages, customerInfo]);

  return (
    <div className="flex h-screen font-sans text-gray-800 dark:text-gray-200 bg-gray-50 dark:bg-gray-800">
      <div className="w-96 flex-shrink-0 flex flex-col p-4 space-y-4 bg-white dark:bg-gray-900 border-r border-gray-200 dark:border-gray-700">
        <h1 className="text-2xl font-bold text-center text-green-700 dark:text-green-400">Chay Tuệ AI</h1>
        <CustomerInfoPanel customerInfo={customerInfo} />
      </div>
      <div className="flex-1 flex flex-col">
        <ChatInterface
          messages={messages}
          onSendMessage={handleSendMessage}
          isLoading={isLoading}
        />
        <footer className="text-center p-2 text-xs text-gray-500 dark:text-gray-400 bg-gray-100 dark:bg-gray-900/50">
          Chatbot Ẩm Thực Chay Tuệ by Plugai.top - <a href="#/login" className="hover:underline text-green-600">Admin</a>
        </footer>
      </div>
    </div>
  );
}

export default ChatView;
