
import { GoogleGenAI } from '@google/genai';
import { Message, Role, GroundingSource } from '../types';

// IMPORTANT: The API key is hardcoded here for demonstration purposes as requested by the user.
// In a production environment, this is a HIGHLY INSECURE practice.
// Anyone with access to your site's code can see and use your API key, potentially leading to high costs.
// It is strongly recommended to manage your API key through a secure backend or environment variables
// provided by your hosting platform.
const API_KEY = "AIzaSyDzMOeUW-zDXSeejjr4y6NT23ZOj_BHd2Y"; // <--- PASTE YOUR VALID GEMINI API KEY HERE

const ai = new GoogleGenAI({ apiKey: API_KEY });

const KNOWLEDGE_BASE = `
# TỔNG HỢP THÔNG TIN VỀ NHÀ HÀNG CHAY TUỆ

## 1. GIỚI THIỆU & TRIẾT LÝ
- **Khởi nguồn**: Ẩm Thực Chay Tuệ là chuỗi nhà hàng chay cao cấp với tâm nguyện lan tỏa văn hóa ăn chay, nuôi dưỡng nhân tâm. Sứ mệnh là "Giữ chánh niệm – Sống bình an".
- **Triết lý "Tuệ"**: Tên gọi mang ý nghĩa Giới – Định – Tuệ theo lời dạy của Đức Phật, giúp con người giác ngộ và hiểu rõ bản thân.
- **Cam kết 5 KHÔNG**: Không bột ngọt, không dầu chiên lại, không đường tinh luyện, không muối tinh, không chất bảo quản, đảm bảo sức khỏe cho thực khách.
- **Không gian**: Thiết kế tinh tế, thanh tịnh, lấy cảm hứng từ hoa sen và triết lý nhà Phật, mang lại không gian chữa lành và bình an.

## 2. THÔNG TIN LIÊN HỆ & GIỜ MỞ CỬA
- **Giờ hoạt động**: 7:30 - 22:00 hàng ngày.
  - 7:30 - 10:00: Menu điểm tâm sáng.
  - 10:00 - 21:00: Menu gọi món.
  - 21:00: Nhận order cuối cùng (last order).
  - 22:00: Đóng cửa.
- **Hệ thống chi nhánh**:
  - **Chi nhánh 1**: 76 Mai Thị Lựu, P. Đakao, Q.1 (Đối diện chùa Ngọc Hoàng). Hotline: 090 725 9988
  - **Chi nhánh 2**: 162 Trần Hưng Đạo, P. Nguyễn Cư Trinh, Q.1. Hotline: 094 99 111 62
  - **Chi nhánh 3**: 101 Nguyễn Bính, Khu phố Mỹ Hoàng, P. Tân Phong, Q.7. Hotline: 097 955 3101
- **Tổng đài CSKH**: 079 822 7676
- **Email đặt bàn**: booking@amthucchaytue.com

## 3. THỰC ĐƠN & DỊCH VỤ
- **Các loại menu**:
  - **Menu buffet**: https://amthucchaytue.com/menu-buffet (Dùng tại nhà hàng)
  - **Menu gọi món (Alacarte)**: https://amthucchaytue.com/menu-alacarte/ (Dùng tại nhà hàng & mang về)
  - **Menu mâm cúng**: https://amthucchaytue.com/mam-cung-gia-tien/ (Chỉ bán mang về)
- **Đặt mâm cúng, tiệc**: Tuệ nhận đặt mâm cúng gia tiên, tiệc sinh nhật, tiệc công ty. Tặng voucher 10% cho khách đặt mâm cúng.

## 4. CÁC GÓI BUFFET
- **Lưu ý chung**:
  - Mùng 1 và Rằm không phục vụ buffet do quá tải.
  - Giá vé chưa bao gồm nước.
  - Nhận khách cho tối thiểu 2 người.
- **Buffet trưa 250k++**:
  - **Giá**: 250.000 VNĐ++/khách.
  - **Thời gian**: 11:00 – 13:30 (last order), từ Thứ 2 đến Thứ 6.
  - **Áp dụng**: Cả 3 chi nhánh.
  - **Menu**: Hơn 50 món.
- **Buffet chiều - tối 400k++**:
  - **Giá**: 400.000 VNĐ++/khách.
  - **Thời gian**: 17:00 – 21:00 (last order).
  - **Lịch hoạt động**:
    - **Mai Thị Lựu (Q.1)**: Thứ 3, 4, 6, 7.
    - **Trần Hưng Đạo (Q.1)**: Thứ 3 đến Thứ 5 và Chủ Nhật.
    - **Nguyễn Bính (Q.7)**: Thứ 5 đến Chủ Nhật.
  - **Menu**: Hơn 100 món thượng hạng.
- **Giá vé buffet trẻ em**:
  - Dưới 1m: Miễn phí.
  - Từ 1m - 1m4: 50% giá vé người lớn.
  - Trên 1m4: Tính giá như người lớn.

## 5. KHUYẾN MÃI & ƯU ĐÃI
- **Buffet đi 4 tính 3**: Áp dụng cho buffet 400k khi đặt bàn trước (vé người lớn >1m4).
- **Ưu đãi sinh nhật**: Hỗ trợ setup bong bóng & bảng chúc mừng miễn phí khi đặt bàn trước.
- **Thành viên Tuệ**: Giảm 10% cho mọi đơn hàng trong tháng sinh nhật.
- **Ưu đãi phí ship**:
  - Đơn > 500k: Hỗ trợ 30k.
  - Đơn > 1 triệu: Hỗ trợ 50k.
  - Đơn > 2 triệu: Miễn phí ship (tối đa 100k).
  - Lưu ý: Không áp dụng cho Tuệ Garden Q7 và không tách bill.

## 6. QUY ĐỊNH & TIỆN ÍCH
- **Đặt bàn**: Vui lòng cung cấp: Tên - SĐT - Số lượng - Thời gian - Dùng buffet/gọi món - Chi nhánh.
- **Đặt món mang về**: Vui lòng cung cấp: Tên - SĐT - Địa chỉ - Thời gian giao hàng.
- **Phòng riêng (VIP)**: Có phụ thu. Dưới 6 khách: 500k. Từ 7-12 khách: 300k.
- **Giờ giao hàng**:
  - Sớm nhất từ 8:30 (nếu chốt đơn trước 19h hôm trước).
  - Đơn trong ngày giao sau 10:00.
  - Phụ thu giao sớm (7:00-8:30): 500k cho đơn dưới 3 triệu.
- **Tiện ích**:
  - Có chỗ đậu xe ô tô, xe máy miễn phí.
  - Cấm hút thuốc, có Wifi, ghế trẻ em.
  - Có xuất VAT.
- **Phí dịch vụ & VAT**:
  - Dùng tại quán: 5% phí dịch vụ + 8% VAT.
  - Mua mang về: 8% VAT.
- **Lịch chơi đàn**:
  - **Mai Thị Lựu**: 19:30 - 20:30, Thứ 6 và Thứ 7.
  - **Trần Hưng Đạo**: 19:30 - 20:30, Thứ 5.
`;

function buildSystemInstruction(): string {
    return `You are 'Test chatbot Chay Tuệ', a friendly, gentle, and professional assistant for a vegetarian food brand 'Ẩm Thực Chay Tuệ'.
    Your primary goal is to answer user questions based on the provided KNOWLEDGE BASE.
    If the knowledge base doesn't have the answer, you are allowed to use Google Search to find relevant, up-to-date information.
    Always be polite and use a warm, caring tone. Address the user with respect.
    Format your answers beautifully and professionally using Markdown (e.g., bolding, bullet points).
    Use emojis (like 😊, 🙏, 🌱) where appropriate to make the conversation more lively and friendly.
    If the user provides their name or phone number, extract it.
    Do not make up information. If you use Google Search, you MUST cite your sources at the end of your response.
    Never mention that you are an AI or a language model.

    ---
    KNOWLEDGE BASE:
    ${KNOWLEDGE_BASE}
    ---
    `;
}

export const getBotResponse = async (
  userInput: string,
  history: Message[],
): Promise<{ responseText: string; extractedInfo: { name: string; phone: string } | null, sources: GroundingSource[] | null }> => {
  if (API_KEY === "YOUR_API_KEY_HERE" || !API_KEY) {
    return {
        responseText: "⛔ **Lỗi Cấu Hình API Key**\n\nVui lòng mở file `services/geminiService.ts` và thay thế chuỗi `\"YOUR_API_KEY_HERE\"` bằng API Key hợp lệ của bạn để chatbot có thể hoạt động.",
        extractedInfo: null,
        sources: null
    };
  }

  const systemInstruction = buildSystemInstruction();

  const contents = history
    .filter(msg => msg.id !== 'initial-message') // Exclude the initial welcome message
    .map(msg => ({
      role: msg.role,
      parts: msg.parts,
    }));
  contents.push({ role: Role.USER, parts: [{ text: userInput }] });

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: contents,
      config: {
        systemInstruction: systemInstruction,
        tools: [{ googleSearch: {} }],
      }
    });

    const text = response.text;
    const groundingMetadata = response.candidates?.[0]?.groundingMetadata;
    const sources: GroundingSource[] = groundingMetadata?.groundingChunks
        ?.map(chunk => chunk.web)
        .filter((web): web is GroundingSource => !!web) || [];
    
    // Simple regex for info extraction as a fallback since schema is not used.
    const nameMatch = userInput.match(/(?:tôi là|tên tôi là|tên của tôi là)\s*([A-ZÀ-Ỹ][a-zà-ỹ]+(?:\s[A-ZÀ-Ỹ][a-zà-ỹ]+)*)/i);
    const phoneMatch = userInput.match(/(\b(0|84|\+84)?\d{9}\b)/g);
    
    const extractedInfo = {
        name: nameMatch ? nameMatch[1].trim() : '',
        phone: phoneMatch ? phoneMatch[0] : '',
    };

    return { responseText: text, extractedInfo, sources };
  } catch (error) {
    console.error("Gemini API Error:", error);
    let errorMessage = "Đã có lỗi xảy ra khi kết nối tới Gemini. Vui lòng xem console (F12) để biết thêm chi tiết.";
    if (error instanceof Error && (error.message.includes("API key not valid") || error.message.includes("API_KEY_INVALID")) ) {
        errorMessage = "⛔ **Lỗi Xác Thực API Key**\n\nAPI Key bạn cung cấp không hợp lệ. Vui lòng kiểm tra lại giá trị API Key trong file `services/geminiService.ts`.";
    }
    throw new Error(errorMessage);
  }
};
