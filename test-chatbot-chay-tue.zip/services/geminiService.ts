
import { Message, GroundingSource } from '../types';

// The web chat will now talk to our own server, which then talks to Gemini.
// This centralizes data logging.
const SERVER_API_URL = '/api/chat'; // Using a relative URL to proxy through the development server

export const getBotResponse = async (
  userInput: string,
  history: Message[],
): Promise<{ responseText: string; extractedInfo: { name: string; phone: string } | null, sources: GroundingSource[] | null }> => {
  
  try {
    const response = await fetch(SERVER_API_URL, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ userInput, history, source: 'web' })
    });

    if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Server returned an error');
    }

    const data = await response.json();

    return {
        responseText: data.responseText,
        extractedInfo: data.extractedInfo,
        sources: data.sources
    };

  } catch (error) {
    console.error("API Server Error:", error);
    const errorMessage = "Đã có lỗi xảy ra khi kết nối tới server. Vui lòng đảm bảo server đang chạy và kiểm tra console để biết thêm chi tiết.";
    throw new Error(errorMessage);
  }
};