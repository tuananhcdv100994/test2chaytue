import React from 'react';

const UserCogIcon: React.FC<{className?: string}> = ({ className = "w-6 h-6" }) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    className={className}
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <circle cx="18" cy="15" r="3" />
    <circle cx="9" cy="7" r="4" />
    <path d="M12 15h1.5" />
    <path d="M15.28 12.22a7 7 0 0 0-10.56 0" />
    <path d="M21.17 17.83a2 2 0 0 0-2.34-2.34" />
    <path d="M14.83 12.17a2 2 0 0 0 2.34-2.34" />
    <path d="M14.83 17.83a2 2 0 0 1 2.34 2.34" />
    <path d="M21.17 12.17a2 2 0 0 1-2.34 2.34" />
  </svg>
);

export default UserCogIcon;
