import React, { useState, useEffect, useCallback } from 'react';
import { AdminUser } from './types';
import { initializeStorage, getAdminByUsername } from './lib/storage';
import LoginView from './views/LoginView';
import AdminView from './views/AdminView';
import ChatView from './views/ChatView';

// Simple hash-based router
const useHashRouter = () => {
  const [hash, setHash] = useState(window.location.hash);

  const handleHashChange = useCallback(() => {
    setHash(window.location.hash);
  }, []);

  useEffect(() => {
    window.addEventListener('hashchange', handleHashChange);
    return () => {
      window.removeEventListener('hashchange', handleHashChange);
    };
  }, [handleHashChange]);

  return hash;
};

function App() {
  const [loggedInAdmin, setLoggedInAdmin] = useState<AdminUser | null>(null);
  const hash = useHashRouter();

  useEffect(() => {
    initializeStorage();
    // Check for existing session on load
    const session = sessionStorage.getItem('admin_session');
    if (session) {
      const admin: AdminUser = JSON.parse(session);
      setLoggedInAdmin(admin);
    }
  }, []);

  const handleLogin = (admin: AdminUser) => {
    setLoggedInAdmin(admin);
    sessionStorage.setItem('admin_session', JSON.stringify(admin));
    window.location.hash = '/admin';
  };

  const handleLogout = () => {
    setLoggedInAdmin(null);
    sessionStorage.removeItem('admin_session');
    window.location.hash = '/login';
  };
  
  const renderView = () => {
    if (loggedInAdmin) {
       if(hash.startsWith('#/admin')) {
         return <AdminView admin={loggedInAdmin} onLogout={handleLogout} />;
       }
       // If logged in but not on admin page, redirect to admin
       window.location.hash = '/admin';
       return null;
    }

    if (hash.startsWith('#/login')) {
      return <LoginView onLoginSuccess={handleLogin} />;
    }
    
    // Default view is the chat
    return <ChatView />;
  };

  return <div className="antialiased">{renderView()}</div>;
}

export default App;