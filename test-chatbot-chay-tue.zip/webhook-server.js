// --- Imports ---
import express from 'express';
import 'dotenv/config';
import { GoogleGenAI } from '@google/genai';
import cors from 'cors';
import fs from 'fs/promises';
import path from 'path';

// --- Cấu hình ---
const PORT = process.env.PORT || 3000;
const API_KEY = process.env.API_KEY;
const PAGE_ACCESS_TOKEN = process.env.PAGE_ACCESS_TOKEN;
const VERIFY_TOKEN = process.env.VERIFY_TOKEN;

// --- Database File Paths ---
const DB_DIR = path.join(process.cwd(), 'db');
const MESSAGES_DB_PATH = path.join(DB_DIR, 'messages.json');
const CUSTOMERS_DB_PATH = path.join(DB_DIR, 'customers.json');

// --- Khởi tạo ---
if (!API_KEY || !PAGE_ACCESS_TOKEN || !VERIFY_TOKEN) {
    console.error("Lỗi: Vui lòng cung cấp đủ các biến môi trường: API_KEY, PAGE_ACCESS_TOKEN, VERIFY_TOKEN trong file .env");
    process.exit(1);
}

const ai = new GoogleGenAI({ apiKey: API_KEY });
const app = express();
app.use(cors()); // Enable Cross-Origin Resource Sharing
app.use(express.json());

// --- File-based Database Helpers ---
async function readData(filePath) {
    try {
        await fs.access(filePath);
        const data = await fs.readFile(filePath, 'utf-8');
        return JSON.parse(data);
    } catch (error) {
        // If file doesn't exist, return empty array and it will be created on first write
        if (error.code === 'ENOENT') {
            return [];
        }
        console.error(`Error reading from ${filePath}:`, error);
        throw error;
    }
}

async function writeData(filePath, data) {
    try {
        await fs.mkdir(DB_DIR, { recursive: true }); // Ensure db directory exists
        await fs.writeFile(filePath, JSON.stringify(data, null, 2), 'utf-8');
    } catch (error) {
        console.error(`Error writing to ${filePath}:`, error);
        throw error;
    }
}

// --- Logic Chatbot ---
const KNOWLEDGE_BASE = `
# TỔNG HỢP THÔNG TIN VỀ NHÀ HÀNG CHAY TUỆ
... (Knowledge base content is the same, omitted for brevity) ...
`;

function buildSystemInstruction() {
    return `You are 'Test chatbot Chay Tuệ', a friendly, gentle, and professional assistant for a vegetarian food brand 'Ẩm Thực Chay Tuệ'.
    Your primary goal is to answer user questions based on the provided KNOWLEDGE BASE.
    If the knowledge base doesn't have the answer, you are allowed to use Google Search to find relevant, up-to-date information.
    Always be polite and use a warm, caring tone. Address the user with respect.
    Format your answers beautifully using Markdown.
    Use emojis (like 😊, 🙏, 🌱) where appropriate.
    If the user provides their name or phone number, extract it.
    Do not make up information. If you use Google Search, you MUST cite your sources.
    Never mention that you are an AI or a language model.
    Today's date is ${new Date().toLocaleDateString('vi-VN')}.

    ---
    KNOWLEDGE BASE:
    ${KNOWLEDGE_BASE}
    ---
    `;
}

async function getBotResponse(userInput, history) {
    const systemInstruction = buildSystemInstruction();
    const contents = [...history.map(msg => ({
        role: msg.role,
        parts: msg.parts
    })), { role: 'user', parts: [{ text: userInput }] }];

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: contents,
            config: {
                systemInstruction: systemInstruction,
                tools: [{ googleSearch: {} }],
            }
        });

        const text = response.text;
        const groundingMetadata = response.candidates?.[0]?.groundingMetadata;
        const sources = groundingMetadata?.groundingChunks
            ?.map(chunk => chunk.web)
            .filter((web) => !!web) || [];
        
        return { responseText: text, sources };
    } catch (error) {
        console.error("Gemini API Error:", error);
        return { responseText: "Xin lỗi, tôi đang gặp một chút sự cố kỹ thuật. Vui lòng thử lại sau giây lát nhé. 🙏", sources: [] };
    }
}

function extractCustomerInfo(userInput) {
    const nameMatch = userInput.match(/(?:tôi là|tên tôi là|tên của tôi là)\s*([A-ZÀ-Ỹ][a-zà-ỹ]+(?:\s[A-ZÀ-Ỹ][a-zà-ỹ]+)*)/i);
    const phoneMatch = userInput.match(/(\b(0|84|\+84)?\d{9}\b)/g);
    
    return {
        name: nameMatch ? nameMatch[1].trim() : '',
        phone: phoneMatch ? phoneMatch[0] : '',
    };
}


// --- API Endpoints for Web App ---
app.get('/api/messages', async (req, res) => {
    try {
        const messages = await readData(MESSAGES_DB_PATH);
        res.status(200).json(messages);
    } catch (error) {
        res.status(500).json({ error: 'Failed to read messages' });
    }
});

app.get('/api/customers', async (req, res) => {
    try {
        const customers = await readData(CUSTOMERS_DB_PATH);
        res.status(200).json(customers);
    } catch (error) {
        res.status(500).json({ error: 'Failed to read customers' });
    }
});

app.post('/api/chat', async (req, res) => {
    try {
        const { userInput, history, source } = req.body;

        // 1. Get bot response
        const { responseText, sources } = await getBotResponse(userInput, history);

        // 2. Log messages
        const messages = await readData(MESSAGES_DB_PATH);
        const userMessage = { id: `user-${Date.now()}`, role: 'user', parts: [{ text: userInput }], timestamp: Date.now(), source };
        const botMessage = { id: `bot-${Date.now()}`, role: 'model', parts: [{ text: responseText }], timestamp: Date.now(), source };
        messages.push(userMessage, botMessage);
        await writeData(MESSAGES_DB_PATH, messages);

        // 3. Extract and save customer info
        const extractedInfo = extractCustomerInfo(userInput);
        if (extractedInfo.phone) {
            const customers = await readData(CUSTOMERS_DB_PATH);
            const existingIndex = customers.findIndex(c => c.phone === extractedInfo.phone);
            const customerRecord = {
                name: extractedInfo.name || (existingIndex > -1 ? customers[existingIndex].name : ''),
                phone: extractedInfo.phone,
                timestamp: Date.now(),
                source
            };

            if (existingIndex > -1) {
                customers[existingIndex] = { ...customers[existingIndex], ...customerRecord };
            } else {
                customers.push(customerRecord);
            }
            await writeData(CUSTOMERS_DB_PATH, customers);
        }

        // 4. Send response to client
        res.status(200).json({ responseText, extractedInfo, sources });

    } catch (error) {
        console.error("API /chat Error:", error);
        res.status(500).json({ error: "Internal server error in /api/chat" });
    }
});


// --- Xử lý Webhook Facebook ---
app.get('/webhook', (req, res) => {
    // (Verification logic remains the same)
    const mode = req.query['hub.mode'];
    const token = req.query['hub.verify_token'];
    const challenge = req.query['hub.challenge'];
    if (mode === 'subscribe' && token === VERIFY_TOKEN) {
        res.status(200).send(challenge);
    } else {
        res.sendStatus(403);
    }
});

app.post('/webhook', (req, res) => {
    const body = req.body;
    if (body.object === 'page') {
        body.entry.forEach(entry => {
            const webhook_event = entry.messaging[0];
            const sender_psid = webhook_event.sender.id;
            if (webhook_event.message && webhook_event.message.text) {
                handleMessage(sender_psid, webhook_event.message.text);
            }
        });
        res.status(200).send('EVENT_RECEIVED');
    } else {
        res.sendStatus(404);
    }
});

async function handleMessage(sender_psid, received_message) {
    const allMessages = await readData(MESSAGES_DB_PATH);
    const history = allMessages
        .filter(msg => msg.id.includes(sender_psid)) // A simple way to get user-specific history
        .slice(-10); // Get last 10 messages for context

    const { responseText } = await getBotResponse(received_message, history);

    // Save messages to DB
    const userMessage = { id: `user-${sender_psid}-${Date.now()}`, role: 'user', parts: [{ text: received_message }], timestamp: Date.now(), source: 'messenger' };
    const botMessage = { id: `bot-${sender_psid}-${Date.now()}`, role: 'model', parts: [{ text: responseText }], timestamp: Date.now(), source: 'messenger' };
    allMessages.push(userMessage, botMessage);
    await writeData(MESSAGES_DB_PATH, allMessages);
    
    // Extract and save customer info
    const extractedInfo = extractCustomerInfo(received_message);
    if (extractedInfo.phone) {
        const customers = await readData(CUSTOMERS_DB_PATH);
        const existingIndex = customers.findIndex(c => c.phone === extractedInfo.phone);
         const customerRecord = {
            name: extractedInfo.name || (existingIndex > -1 ? customers[existingIndex].name : `Guest_${sender_psid}`),
            phone: extractedInfo.phone,
            timestamp: Date.now(),
            source: 'messenger'
        };
        if (existingIndex > -1) {
            customers[existingIndex] = { ...customers[existingIndex], ...customerRecord };
        } else {
            customers.push(customerRecord);
        }
        await writeData(CUSTOMERS_DB_PATH, customers);
    }

    callSendAPI(sender_psid, { text: responseText });
}

function callSendAPI(sender_psid, response) {
    const request_body = {
        recipient: { id: sender_psid },
        message: response,
        messaging_type: "RESPONSE"
    };

    fetch(`https://graph.facebook.com/v19.0/me/messages?access_token=${PAGE_ACCESS_TOKEN}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(request_body)
    }).then(res => res.json()).then(data => {
        if (data.error) console.error("Facebook Send API Error:", data.error);
    }).catch(err => console.error("Cannot send message:", err));
}

// --- Khởi động Server ---
app.listen(PORT, () => {
    console.log(`Webhook server & API is listening on http://localhost:${PORT}`);
});
