
require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const { GoogleGenAI } = require('@google/genai');

// --- Cấu hình ---
const PORT = process.env.PORT || 3000;
const API_KEY = process.env.API_KEY;
const PAGE_ACCESS_TOKEN = process.env.PAGE_ACCESS_TOKEN;
const VERIFY_TOKEN = process.env.VERIFY_TOKEN;

if (!API_KEY || !PAGE_ACCESS_TOKEN || !VERIFY_TOKEN) {
    console.error("Lỗi: Vui lòng cung cấp đủ các biến môi trường: API_KEY, PAGE_ACCESS_TOKEN, VERIFY_TOKEN trong file .env");
    process.exit(1);
}

const ai = new GoogleGenAI({ apiKey: API_KEY });
const app = express().use(bodyParser.json());

// Lưu trữ lịch sử trò chuyện cho từng người dùng (trong bộ nhớ, sẽ reset khi server khởi động lại)
const conversationHistories = {};

// --- Logic Chatbot (Tái sử dụng từ frontend) ---
const KNOWLEDGE_BASE = `
# TỔNG HỢP THÔNG TIN VỀ NHÀ HÀNG CHAY TUỆ

## 1. GIỚI THIỆU & TRIẾT LÝ
- **Khởi nguồn**: Ẩm Thực Chay Tuệ là chuỗi nhà hàng chay cao cấp với tâm nguyện lan tỏa văn hóa ăn chay, nuôi dưỡng nhân tâm. Sứ mệnh là "Giữ chánh niệm – Sống bình an".
- **Triết lý "Tuệ"**: Tên gọi mang ý nghĩa Giới – Định – Tuệ theo lời dạy của Đức Phật, giúp con người giác ngộ và hiểu rõ bản thân.
- **Cam kết 5 KHÔNG**: Không bột ngọt, không dầu chiên lại, không đường tinh luyện, không muối tinh, không chất bảo quản, đảm bảo sức khỏe cho thực khách.
- **Không gian**: Thiết kế tinh tế, thanh tịnh, lấy cảm hứng từ hoa sen và triết lý nhà Phật, mang lại không gian chữa lành và bình an.

## 2. THÔNG TIN LIÊN HỆ & GIỜ MỞ CỬA
- **Giờ hoạt động**: 7:30 - 22:00 hàng ngày.
  - 7:30 - 10:00: Menu điểm tâm sáng.
  - 10:00 - 21:00: Menu gọi món.
  - 21:00: Nhận order cuối cùng (last order).
  - 22:00: Đóng cửa.
- **Hệ thống chi nhánh**:
  - **Chi nhánh 1**: 76 Mai Thị Lựu, P. Đakao, Q.1 (Đối diện chùa Ngọc Hoàng). Hotline: 090 725 9988
  - **Chi nhánh 2**: 162 Trần Hưng Đạo, P. Nguyễn Cư Trinh, Q.1. Hotline: 094 99 111 62
  - **Chi nhánh 3**: 101 Nguyễn Bính, Khu phố Mỹ Hoàng, P. Tân Phong, Q.7. Hotline: 097 955 3101
- **Tổng đài CSKH**: 079 822 7676
- **Email đặt bàn**: booking@amthucchaytue.com

## 3. THỰC ĐƠN & DỊCH VỤ
- **Các loại menu**:
  - **Menu buffet**: https://amthucchaytue.com/menu-buffet (Dùng tại nhà hàng)
  - **Menu gọi món (Alacarte)**: https://amthucchaytue.com/menu-alacarte/ (Dùng tại nhà hàng & mang về)
  - **Menu mâm cúng**: https://amthucchaytue.com/mam-cung-gia-tien/ (Chỉ bán mang về)
- **Đặt mâm cúng, tiệc**: Tuệ nhận đặt mâm cúng gia tiên, tiệc sinh nhật, tiệc công ty. Tặng voucher 10% cho khách đặt mâm cúng.
`;

function buildSystemInstruction() {
    return `You are 'Test chatbot Chay Tuệ', a friendly, gentle, and professional assistant for a vegetarian food brand 'Ẩm Thực Chay Tuệ'.
    Your primary goal is to answer user questions based on the provided KNOWLEDGE BASE.
    Always be polite and use a warm, caring tone. Address the user with respect.
    Format your answers beautifully for Messenger (use new lines, but avoid Markdown as it's not fully supported).
    Use emojis (like 😊, 🙏, 🌱) where appropriate to make the conversation more lively and friendly.
    If the user provides their name or phone number, extract it.
    Do not make up information.
    Never mention that you are an AI or a language model.

    ---
    KNOWLEDGE BASE:
    ${KNOWLEDGE_BASE}
    ---
    `;
}

async function getBotResponse(userInput, history) {
  const systemInstruction = buildSystemInstruction();
  const contents = [...history, { role: 'user', parts: [{ text: userInput }] }];

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: contents,
      config: {
        systemInstruction: systemInstruction,
      }
    });
    return response.text;
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Xin lỗi, tôi đang gặp một chút sự cố kỹ thuật. Vui lòng thử lại sau giây lát nhé. 🙏";
  }
}


// --- Xử lý Webhook Facebook ---

// Endpoint để xác thực webhook
app.get('/webhook', (req, res) => {
    const mode = req.query['hub.mode'];
    const token = req.query['hub.verify_token'];
    const challenge = req.query['hub.challenge'];

    if (mode && token) {
        if (mode === 'subscribe' && token === VERIFY_TOKEN) {
            console.log('WEBHOOK_VERIFIED');
            res.status(200).send(challenge);
        } else {
            res.sendStatus(403);
        }
    }
});

// Endpoint để nhận tin nhắn từ người dùng
app.post('/webhook', (req, res) => {
    const body = req.body;

    if (body.object === 'page') {
        body.entry.forEach(entry => {
            const webhook_event = entry.messaging[0];
            const sender_psid = webhook_event.sender.id;

            if (webhook_event.message && webhook_event.message.text) {
                handleMessage(sender_psid, webhook_event.message.text);
            }
        });
        res.status(200).send('EVENT_RECEIVED');
    } else {
        res.sendStatus(404);
    }
});

// Xử lý tin nhắn và lấy phản hồi từ bot
async function handleMessage(sender_psid, received_message) {
    // Khởi tạo lịch sử nếu là người dùng mới
    if (!conversationHistories[sender_psid]) {
        conversationHistories[sender_psid] = [];
    }

    const history = conversationHistories[sender_psid];
    const responseText = await getBotResponse(received_message, history);

    // Cập nhật lịch sử
    history.push({ role: 'user', parts: [{ text: received_message }] });
    history.push({ role: 'model', parts: [{ text: responseText }] });
    // Giới hạn lịch sử để tránh quá dài
    if (history.length > 10) {
        conversationHistories[sender_psid] = history.slice(-10);
    }
    
    callSendAPI(sender_psid, { text: responseText });
}

// Gửi tin nhắn trả lời lại cho người dùng qua Messenger API
function callSendAPI(sender_psid, response) {
    const request_body = {
        "recipient": {
            "id": sender_psid
        },
        "message": response,
        "messaging_type": "RESPONSE"
    };

    fetch(`https://graph.facebook.com/v19.0/me/messages?access_token=${PAGE_ACCESS_TOKEN}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(request_body)
    })
    .then(res => res.json())
    .then(data => {
        if(data.error) {
            console.error("Lỗi khi gửi tin nhắn Facebook:", data.error);
        } else {
            console.log("Đã gửi tin nhắn thành công!");
        }
    })
    .catch(err => console.error("Không thể gửi tin nhắn:", err));
}


// --- Khởi động Server ---
app.listen(PORT, () => {
    console.log(`Webhook server đang lắng nghe tại http://localhost:${PORT}`);
});
