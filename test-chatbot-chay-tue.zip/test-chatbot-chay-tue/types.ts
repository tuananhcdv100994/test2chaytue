
export enum Role {
  USER = 'user',
  MODEL = 'model'
}

export interface MessagePart {
    text: string;
}

export interface Message {
  id: string;
  role: Role;
  parts: MessagePart[];
}

export interface CustomerInfo {
  name: string;
  phone: string;
}

export interface GroundingSource {
    uri: string;
    title: string;
}

// NEW TYPES FOR ADMIN
export enum UserRole {
  ADMIN = 'admin',
  STAFF = 'staff'
}

export interface AdminUser {
  id: string;
  username: string;
  password: string; // In a real app, this would be a hash
  role: UserRole;
}
