export enum Role {
  USER = 'user',
  MODEL = 'model'
}

export interface MessagePart {
    text: string;
}

export interface Message {
  id: string;
  role: Role;
  parts: MessagePart[];
  timestamp: number;
}

export interface CustomerInfo {
  name: string;
  phone: string;
  timestamp: number;
}

export interface GroundingSource {
    uri: string;
    title: string;
}

export enum AdminRole {
  SUPER = 'super',
  ADMIN = 'admin',
}

export interface AdminUser {
  id: string;
  username: string;
  passwordHash: string; // This is a mock hash for demonstration
  role: AdminRole;
}
