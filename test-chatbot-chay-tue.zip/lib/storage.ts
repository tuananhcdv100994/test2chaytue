import { AdminUser, AdminRole, Message, CustomerInfo } from '../types';

// Simple mock for hashing. In a real app, use a proper library like bcrypt.
const mockHash = (password: string): string => {
  return `hashed_${password}_mock`;
};

const STORAGE_KEYS = {
  ADMINS: 'chaytue_admins',
  MESSAGES: 'chaytue_messages',
  CUSTOMERS: 'chaytue_customers',
};

// --- Admin Management ---
export const getAdmins = (): AdminUser[] => {
  const data = localStorage.getItem(STORAGE_KEYS.ADMINS);
  return data ? JSON.parse(data) : [];
};

export const saveAdmins = (admins: AdminUser[]) => {
  localStorage.setItem(STORAGE_KEYS.ADMINS, JSON.stringify(admins));
};

export const getAdminByUsername = (username: string): AdminUser | undefined => {
  return getAdmins().find(admin => admin.username === username);
};

export const verifyPassword = (password: string, hash: string): boolean => {
  return mockHash(password) === hash;
};

// --- Messages Management ---
export const getMessages = (): Message[] => {
  const data = localStorage.getItem(STORAGE_KEYS.MESSAGES);
  return data ? JSON.parse(data) : [];
};

export const addMessage = (message: Message) => {
  const messages = getMessages();
  messages.push(message);
  localStorage.setItem(STORAGE_KEYS.MESSAGES, JSON.stringify(messages));
};

// --- Customers Management ---
export const getCustomers = (): CustomerInfo[] => {
  const data = localStorage.getItem(STORAGE_KEYS.CUSTOMERS);
  return data ? JSON.parse(data) : [];
};

export const addCustomer = (customer: CustomerInfo) => {
  const customers = getCustomers();
  // Avoid duplicate phone numbers, update existing instead
  const existingIndex = customers.findIndex(c => c.phone === customer.phone);
  if (existingIndex > -1) {
    customers[existingIndex] = { ...customers[existingIndex], ...customer };
  } else {
    customers.push(customer);
  }
  localStorage.setItem(STORAGE_KEYS.CUSTOMERS, JSON.stringify(customers));
};


// --- Initialization ---
export const initializeStorage = () => {
  if (!localStorage.getItem(STORAGE_KEYS.ADMINS)) {
    const initialAdmins: AdminUser[] = [
      {
        id: `admin-${Date.now()}`,
        username: 'testchaytue',
        passwordHash: mockHash('123456'),
        role: AdminRole.SUPER,
      },
    ];
    saveAdmins(initialAdmins);
  }
  if (!localStorage.getItem(STORAGE_KEYS.MESSAGES)) {
    localStorage.setItem(STORAGE_KEYS.MESSAGES, '[]');
  }
  if (!localStorage.getItem(STORAGE_KEYS.CUSTOMERS)) {
    localStorage.setItem(STORAGE_KEYS.CUSTOMERS, '[]');
  }
};
