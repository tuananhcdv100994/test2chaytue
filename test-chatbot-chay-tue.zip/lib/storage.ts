import { AdminUser, AdminRole } from '../types';

// Simple mock for hashing. In a real app, use a proper library like bcrypt.
const mockHash = (password: string): string => {
  return `hashed_${password}_mock`;
};

const STORAGE_KEYS = {
  ADMINS: 'chaytue_admins',
};

// --- Admin Management ---
export const getAdmins = (): AdminUser[] => {
  const data = localStorage.getItem(STORAGE_KEYS.ADMINS);
  return data ? JSON.parse(data) : [];
};

export const saveAdmins = (admins: AdminUser[]) => {
  localStorage.setItem(STORAGE_KEYS.ADMINS, JSON.stringify(admins));
};

export const getAdminByUsername = (username: string): AdminUser | undefined => {
  return getAdmins().find(admin => admin.username === username);
};

export const verifyPassword = (password: string, hash: string): boolean => {
  return mockHash(password) === hash;
};


// --- Initialization ---
export const initializeStorage = () => {
  if (!localStorage.getItem(STORAGE_KEYS.ADMINS)) {
    const initialAdmins: AdminUser[] = [
      {
        id: `admin-${Date.now()}`,
        username: 'testchaytue',
        passwordHash: mockHash('123456'),
        role: AdminRole.SUPER,
      },
    ];
    saveAdmins(initialAdmins);
  }
};